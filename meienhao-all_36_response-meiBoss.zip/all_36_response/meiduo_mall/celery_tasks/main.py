import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'meiduo_mall.settings.dev')

# 导入Celery
from celery import Celery

# 创建Celery()===> 对象
celery_app = Celery('meiduo_mall')

# 给对象配置添加一个配置文件 ===> config.py
celery_app.config_from_object('celery_tasks.config')

# 定义任务
# 给对象关联任务
celery_app.autodiscover_tasks(['celery_tasks.sms', 'celery_tasks.email', 'celery_tasks.html'])