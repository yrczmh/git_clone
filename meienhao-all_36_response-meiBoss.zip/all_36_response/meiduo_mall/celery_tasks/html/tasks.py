import sys

sys.path.insert(0, '../../')

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'meiduo_mall.settings.dev')

# 初始化django
import django
django.setup()

from django.template import loader
from django.conf import settings
from celery_tasks.main import celery_app
from goods.utils import get_goods_and_spec, get_categories
import os

@celery_app.task(name='generate_detail_func')
def generate_detail_func(sku_id):
    '''生成详情页'''

    # 详情页获取的主要数据
    goods, specs, sku = get_goods_and_spec(sku_id)

    # 获取的详情页需要的商品分类数据:
    dict = get_categories()

    # 渲染模板，生成静态html文件
    context = {
        'categories': dict,
        'goods': goods,
        'specs': specs,
        'sku': sku
    }

    # 获取详情页的模板:
    template = loader.get_template('detail.html')

    wanzhengdeyemian = template.render(context)

    file_path = os.path.join(settings.GENERATED_STATIC_HTML_FILES_DIR, 'goods/%s.html' % str(sku_id))

    with open(file_path, 'w', encoding='utf8') as f:

        f.write(wanzhengdeyemian)


# if __name__ == '__main__':
#
#     generate_detail_func(1)


if __name__ == '__main__':
    for i in range(1,17):
        print(i)
        generate_detail_func(i)


    # skus = SKU.objects.all()

    # count = SKU.objects.filter(is_launched=True).count()
    #
    # for i in range(1, count+1):
    #     print(i)
    #
    #     generate_detail_func.delay(i)


    # for sku in skus:
    #
    #     print(sku.id)
    #
    #     generate_detail_func.delay(sku.id)

