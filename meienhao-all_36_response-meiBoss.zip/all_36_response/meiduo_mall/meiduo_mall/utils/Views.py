from django.http import JsonResponse



# 我们自定义的装饰器:
def my_decorator_1(func):
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            # 登录成功
            return func(request, *args, **kwargs)
        else:
            # 未登录的用户:
            # 未登录用户
            return JsonResponse({'code': 400,
                                 'errmsg': '未登录, 请登录后访问'})
    return wrapper





# 定义一个Mixin扩展类:
class LoginRequiredMixin(object):

    @classmethod
    def as_view(cls, *args, **kwargs):
        view = super().as_view(*args, **kwargs)
        return my_decorator_1(view)