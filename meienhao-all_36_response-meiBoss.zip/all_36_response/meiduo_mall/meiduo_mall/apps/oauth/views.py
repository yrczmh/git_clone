from QQLoginTool.QQtool import OAuthQQ
from django.contrib.auth import login
from django.views import  View
from django.conf import settings
from django.http import JsonResponse
import json, re

from carts.utils import merge_carts_cookie_to_redis
from oauth.models import OAuthQQUser
from oauth.utils import generate_access_token, check_access_token
from django_redis import get_redis_connection

from users.models import User


class QQFirstView(View):

    def get(self, request):
        '''qq登录的第一个接口, 返回qq登录的地址'''

        # 1.接收参数
        next = request.GET.get('next')

        # 2.根据QQLoginTool工具类中的类,生成对象
        oauth = OAuthQQ(client_id=settings.QQ_CLIENT_ID,
                        client_secret=settings.QQ_CLIENT_SECRET,
                        redirect_uri=settings.QQ_REDIRECT_URI,
                        state=next)

        # 3.调用对象的get_qq_url()方法, 获取对应的登录地址
        url = oauth.get_qq_url()

        # 4.拼接json参数, 返回
        return JsonResponse({
            'code':0,
            'errmsg':'ok',
            'login_url':url
        })



class QQSecondView(View):


    def get(self, request):
        '''根据code获取openid, 根据openid查看是否登录成功'''

        # 1.接收code参数
        code = request.GET.get('code')

        # 2.检验参数
        if not code:
            return JsonResponse({'code':400,
                                 'errmsg':"缺少必传参数"})

        # 3.创建QQLoginTool工具类的对象
        oauth = OAuthQQ(client_id=settings.QQ_CLIENT_ID,
                        client_secret=settings.QQ_CLIENT_SECRET,
                        redirect_uri=settings.QQ_REDIRECT_URI)
        try:
            # 4.调用对象的方法, 根据code获取access_token
            access_token = oauth.get_access_token(code)

            # 5.根据access_token获取openid
            openid = oauth.get_open_id(access_token)

        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': "发送请求失败"})

        try:
        # 6.根据openid去QQ的表中查询, 查看是否有记录
            oauth_qq = OAuthQQUser.objects.get(openid=openid)
        except Exception as e:

            # 7.如果没有记录: 检验失败 openid===>access_token
            # 12.自定义一个函数, 把openid加密为:access_token
            access_token = generate_access_token(openid)

            # 13.返回json字符串(access_token)
            return JsonResponse({'code':400,
                                 'errmsg':'ok',
                                 'access_token':access_token})
        else:
            # 8.如果有记录: 说明登录成功

            user = oauth_qq.user

            # 9.实现状态保持
            login(request, user)

            response = JsonResponse({'code':0,
                                     'errmsg':'ok'})

            # 10.往cookie中写入username
            response.set_cookie('username', user.username, max_age=3600 * 24 * 14)

            # 增加合并购物车功能:
            response = merge_carts_cookie_to_redis(request, response)

            # 11.返回响应
            return response

    def post(self, request):
        '''绑定用户数据'''

        # 1.接收参数json
        dict = json.loads(request.body)
        mobile = dict.get('mobile')
        password = dict.get('password')
        sms_code_client = dict.get('sms_code')
        access_token = dict.get('access_token')

        # 2.总体检验
        if not all([mobile, password, sms_code_client, access_token]):
            return JsonResponse({'code':400,
                                 'errmsg':'缺少参数'})

        # 3.单个检验mobile
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return JsonResponse({'code': 400,
                                 'errmsg': 'mobile有误'})

        # 4.单个检验password
        if not re.match(r'^[a-zA-Z0-9]{8,20}$', password):
            return JsonResponse({'code': 400,
                                 'errmsg': 'password有误'})

        # 5.单个检验sms_code, 链接redis, 获取链接对象
        redis_conn = get_redis_connection('verify_code')

        # 6.从redis中去sms_code
        sms_code_server = redis_conn.get('sms_%s' % mobile)

        # 7.判断sms_code是否存在
        if sms_code_server is None:
            return JsonResponse({'code': 400,
                                 'errmsg': '验证码过期'})

        # 8.对比前后端的sms_code
        if sms_code_client != sms_code_server.decode():
            return JsonResponse({'code': 400,
                                 'errmsg': '输入的验证码有误'})

        # 9.自定义一个函数,把access_token解密===> openid
        openid = check_access_token(access_token)

        if openid is None:
            return JsonResponse({'code': 400,
                                 'errmsg': 'access_token有误'})
        try:
            # 10.先从User模型类中获取该mobile的用户, 查看是否能够获取到
            user = User.objects.get(mobile=mobile)
        except Exception as e:
            # 12.如果获取不到, 新增一个User表对象
            user = User.objects.create_user(username=mobile,
                                     password=password,
                                     mobile=mobile)
        else:
            # 11.如果能够获取到, 检验密码
            if not user.check_password(password):
                return JsonResponse({'code': 400,
                                     'errmsg': '密码错误'})
        try:
            # 13.向QQ表中增加一个数据
            OAuthQQUser.objects.create(openid=openid,
                                       user=user)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': '写入数据库出错'})

        # 14.状态保持
        login(request, user)

        response = JsonResponse({'code': 0,
                                 'errmsg': 'ok'})

        # 15.cookie中写入username
        response.set_cookie('username', user.username, max_age=3600 * 24 *  14)

        # 增加合并购物车功能:
        response = merge_carts_cookie_to_redis(request, response)

        # 16.返回json
        return response





























