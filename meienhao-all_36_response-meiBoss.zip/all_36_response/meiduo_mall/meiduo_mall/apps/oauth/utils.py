from itsdangerous import TimedJSONWebSignatureSerializer, BadData
from django.conf import settings

def generate_access_token(openid):
    '''把openid加密为acess_token'''

    dict = {
        'openid':openid
    }

    # TimedJSONWebSignatureSerializer(秘钥, 有效期(s))
    obj = TimedJSONWebSignatureSerializer(settings.SECRET_KEY, 600)

    token_bytes = obj.dumps(dict)

    return token_bytes.decode()


def check_access_token(access_token):
    '''把access_token解密'''

    obj = TimedJSONWebSignatureSerializer(settings.SECRET_KEY, 600)

    try:
        data = obj.loads(access_token)
    except BadData:
        return None
    else:
        return data.get('openid')
