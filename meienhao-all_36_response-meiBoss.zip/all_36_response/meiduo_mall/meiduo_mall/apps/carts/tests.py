import pickle, base64


if __name__ == '__main__':

    dict = {
        'name':'zs',
        'age':123
    }

    # python中常见的类型转为bytes:
    result = pickle.dumps(dict)
    print(result)


    result1 = base64.b64encode(result)
    print(result1)

    result2 = result1.decode()
    print(result2)


    # 合着写:
    # 加密:
    result3 = base64.b64encode(pickle.dumps(dict)).decode()
    print(result3)

    # 解密:
    result4 =  pickle.loads(base64.b64decode(result3))
    print(result4)








    # result1 = pickle.loads(result)
    # print(result1)
