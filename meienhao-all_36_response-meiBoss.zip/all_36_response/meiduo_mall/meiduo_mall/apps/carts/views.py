import base64
import pickle

from django.views import View
import json
from django.http import JsonResponse
from django_redis import get_redis_connection


# Create your views here.
from goods.models import SKU


class CartsView(View):

    def post(self, request):
        '''增加购物车'''

        # 1.接收参数(3个: sku_id, count, selected)
        dict = json.loads(request.body)
        sku_id = dict.get('sku_id')
        count = dict.get('count')
        selected = dict.get('selected', True)

        # 2.检验参数
        if not all([sku_id, count]):
            return JsonResponse({'code':400,
                                 'errmsg':'缺少参数'})

        try:
            SKU.objects.get(id=sku_id)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': 'sku_id有误'})

        try:
            count = int(count)

            if count <= 0:
                return JsonResponse({'code': 400,
                                     'errmsg': 'count小于0'})
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': 'count有误'})

        # 3.判断用户是否登录
        if request.user.is_authenticated:
            # 4.如果用户登录:
            # 5.链接redis, 获取链接对象
            redis_conn = get_redis_connection('carts')

            user_id = request.user.id

            pl = redis_conn.pipeline()

            # 6.往hash中写入数据
            # hincrby函数可以实现累加
            pl.hincrby('carts_%s' % user_id,
                               sku_id,
                               count)

            # 7.往set中写入数据(如果该商品的selected为true, 增加)
            if selected:
                pl.sadd('selected_%s' % user_id , sku_id)

            # 执行管道:
            pl.execute()

            # 8.返回json
            return JsonResponse({'code': 0,
                                 'errmsg': 'ok'})

        else:
            # 9.未登录用户
            # 10.先获取cookie中的数据(加过密的数据)
            cookie_cart = request.COOKIES.get('carts')

            # 11.判断该数据是否存在
            if cookie_cart:
                # 12.如果存在, 解密 ===> dict
                cart_dict = pickle.loads(base64.b64decode(cookie_cart))
            else:
                # 13.如果不存在, 创建一个新的dict
                cart_dict = {}

            # 14.判断前端传入的sku_id是否在dict中
            if sku_id in cart_dict:
                # 15.如果在, 该商品的个数累加
                count += cart_dict[sku_id]['count']


            # 16.把sku_id,count(累加过的), selected保存到dict中
            cart_dict[sku_id] = {
                'count':count,
                'selected':selected
            }

            # 17.把dict加密
            cart_data = base64.b64encode(pickle.dumps(cart_dict)).decode()


            response = JsonResponse({'code': 0,
                                 'errmsg': 'ok'})

            # 18.把加密后的数据写入到cookie中
            response.set_cookie('carts', cart_data, max_age=3600 * 24 * 14)

            # 19.返回json
            return response


    def get(self, request):
        '''返回购物车数据'''

        # 1.判断用户是否登录
        if request.user.is_authenticated:
            # 2.如果登录
            # 3.链接redis, 获取链接对象
            redis_conn = get_redis_connection('carts')

            # 4.从hash中取值: item_dict
            item_dict = redis_conn.hgetall('carts_%s' % request.user.id)

            # 5.从set中取值: selected_item
            selected_item = redis_conn.smembers('selected_%s' %  request.user.id)

            cart_dict = {}
            # 6.构造一个dict, 把hash中的sku_id&count以及set中的状态保存进去
            for sku_id, count in item_dict.items():
                cart_dict[int(sku_id)] = {
                    'count':int(count),
                    'selected':sku_id in selected_item
                }
        else:
            # 7.如果未登录:
            # 8.从cookie中获取数据
            cookie_cart = request.COOKIES.get('carts')

            # 9.判断该数据是否存在
            if cookie_cart:
                # 10.如果存在====> 解密 ===> dict
                cart_dict = pickle.loads(base64.b64decode(cookie_cart))
            else:
                # 11.如果不存在, 新键一个dict
                cart_dict = {}

        # 共同的操作:
        # 12.从dict取出所有的sku_ids
        sku_ids = cart_dict.keys()

        try:
            # 13.把sku_ids ===> skus
            skus = SKU.objects.filter(id__in=sku_ids)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': '获取数据有误'})
        list = []

        # 14.遍历skus ===> sku ===> {}  ===> []
        for sku in skus:
            list.append({
                'id':sku.id,
                'selected':cart_dict[sku.id]['selected'],
                'default_image_url':sku.default_image_url,
                'name':sku.name,
                'price':sku.price,
                'count':cart_dict[sku.id]['count'],
                'amount':(sku.price * cart_dict[sku.id]['count'])
            })
        # 15.返回json
        return  JsonResponse({'code': 0,
                              'errmsg': 'ok',
                              'cart_skus':list})


    def put(self, request):
        '''修改购物车'''

        # 1.接收参数(3个: sku_id, count, selected)
        dict = json.loads(request.body)
        sku_id = dict.get('sku_id')
        count = dict.get('count')
        selected = dict.get('selected', True)

        # 2.检验参数
        if not all([sku_id, count]):
            return JsonResponse({'code': 400,
                                 'errmsg': '缺少参数'})

        try:
            SKU.objects.get(id=sku_id)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': 'sku_id有误'})

        try:
            count = int(count)

            if count <= 0:
                return JsonResponse({'code': 400,
                                     'errmsg': 'count小于0'})
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': 'count有误'})

        if selected:
            if not isinstance(selected, bool):
                return JsonResponse({'code': 400,
                                     'errmsg': 'selected类型有误'})

        # 3.判断用户是否登录
        if request.user.is_authenticated:
            # 4.如果登录
            # 5.链接redis, 获取链接对象
            redis_conn = get_redis_connection('carts')

            user_id = request.user.id

            pl = redis_conn.pipeline()

            # 6.把数据写入hash
            pl.hset('carts_%s' % user_id,
                       sku_id,
                       count)

            # 7.根据selected,如果为true,把数据写入set,如果为false, 从set中移出
            if selected:
                pl.sadd('selected_%s' % user_id, sku_id)
            else:
                pl.srem('selected_%s' % user_id, sku_id)

            # 执行管道:
            pl.execute()

            # 8.拼接参数, 返回
            return JsonResponse({'code': 0,
                                 'errmsg': 'ok',
                                 "cart_sku": {
                                     'id': sku_id,
                                     'count': count,
                                     'selected': selected
                                 }})
        else:
            # 9.如果用户未登录
            # 10.从cookie获取值
            cookie_cart = request.COOKIES.get('carts')

            # 11.判断该数据是否存在
            if cookie_cart:
                # 12.如果存在, 解密 ===> dict
                cart_dict = pickle.loads(base64.b64decode(cookie_cart))
            else:
                # 13.如果不存在, 创建一个新的dict
                cart_dict = {}

            # 14.把前端发来的数据写入dict
            cart_dict[sku_id] = {
                'count': count,
                'selected': selected
            }

            # 15.把dict加密
            cart_data = base64.b64encode(pickle.dumps(cart_dict)).decode()

            response = JsonResponse({'code': 0,
                                     'errmsg': 'ok',
                                     "cart_sku": {
                                         'id': sku_id,
                                         'count': count,
                                         'selected': selected
                                     }})

            # 16.把加密的数据写入cookie
            response.set_cookie('carts', cart_data, max_age=3600 * 24 * 14)

            # 17.返回json
            return response



    def delete(self, request):
        '''删除购物车数据'''

        # 1.接收json参数
        dict = json.loads(request.body)
        sku_id = dict.get('sku_id')

        # 2.检验该参数
        if not sku_id:
            return JsonResponse({'code': 400,
                                 'errmsg': '缺少参数'})

        try:
            SKU.objects.get(id=sku_id)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': 'sku_id有误'})

        # 3.判断用户是否登录
        if request.user.is_authenticated:
            # 4.如果登录:
            # 5.链接redis, 获取链接对象
            redis_conn = get_redis_connection('carts')

            user_id = request.user.id

            pl = redis_conn.pipeline()

            # 6.从hash中删除该id对应的数据
            pl.hdel('carts_%s' % user_id, sku_id)

            # 7.从set中删除该id对应的数据
            pl.srem('selected_%s' % user_id, sku_id)

            # 执行管道:
            pl.execute()

            # 8.拼接参数, 返回
            return JsonResponse({'code': 0,
                                 'errmsg': 'ok'
                                 })

        else:
            # 9.如果未登录
            # 10.从cookie中获取数据
            cookie_cart = request.COOKIES.get('carts')

            # 11.判断该数据是否存在, 如果存在, 解密 ===> dict
            if cookie_cart:
                cart_dict = pickle.loads(base64.b64decode(cookie_cart))
            else:
                # 12.如果不存在, 创建一个新的dict
                cart_dict = {}

            response = JsonResponse({'code': 0,
                                     'errmsg': 'ok'})

            # 13.判断id是否在dict中, 如果在, 删除该行数据
            if sku_id in cart_dict:

                # 14.把剩下的dict加密
                del cart_dict[sku_id]

                # 15.把加过密的数据写入cookie
                cart_data = base64.b64encode(pickle.dumps(cart_dict)).decode()

                response.set_cookie('carts', cart_data, max_age=3600 * 24 * 14 )

            # 16.返回
            return response



class SelectedAllCartsView(View):

    def put(self, request):
        '''全选购物车'''

        # 1.接收json参数: selected
        dict = json.loads(request.body)
        selected = dict.get('selected', True)

        # 2.检验该值
        if selected:
            if not isinstance(selected, bool):
                return JsonResponse({'code':400,
                                     'errmsg':'参数错误'})

        # 3.判断用户是否登录
        if request.user.is_authenticated:
            # 4.如果登录:
            # 5.链接redis, 获取链接对象
            redis_conn = get_redis_connection('carts')

            # 6.获取hash中的所有的sku_ids
            item_dict = redis_conn.hgetall('carts_%s' % request.user.id)
            sku_ids = item_dict.keys()

            # 7.判断前端传的selected是否是true, 如果是: 把所有的sku_ids加入set, 否则相反
            if selected:
                # true:
                redis_conn.sadd('selected_%s' % request.user.id, *sku_ids)
            else:
                # false:
                redis_conn.srem('selected_%s' % request.user.id, *sku_ids)

            # 8.返回json
            return JsonResponse({'code': 0,
                                 'errmsg': 'ok'})
        else:
            # 9.如果未登录
            # 10.从cookie中获取数据
            cookie_cart = request.COOKIES.get('carts')

            response = JsonResponse({'code': 0,
                                     'errmsg': 'ok'})

            # 11.判断是否存在, 如果存在 ===> 解密 ===> dict
            if cookie_cart:
                cart_dict = pickle.loads(base64.b64decode(cookie_cart))

                # 12.遍历dict, 获取dict中的selected, 用前端传入的selected替换他
                for sku_id in cart_dict.keys():
                    cart_dict[sku_id]['selected'] = selected

                # 13.把dict加密
                cart_data = base64.b64encode(pickle.dumps(cart_dict)).decode()

                # 14.写入cookie
                response.set_cookie('carts', cart_data, max_age=3600 * 24 * 14)

            # 15.返回
            return response


class CartsSimpleView(View):

    def get(self, request):
        '''返回简易购物车数据'''

        # 1.判断用户是否登录
        if request.user.is_authenticated:
            # 2.如果登录
            # 3.链接redis, 获取链接对象
            redis_conn = get_redis_connection('carts')

            # 4.从hash中获取数据
            item_dict = redis_conn.hgetall('carts_%s' % request.user.id)

            # 5.从set中获取数据
            selected_item = redis_conn.smembers('selected_%s' % request.user.id)

            cart_dict = {}

            # 6.拼接cart_dict
            for sku_id, count in item_dict.items():
                cart_dict[int(sku_id)] = {
                    'count':int(count),
                    'selected':sku_id in selected_item
                }
        else:
            # 7.如果未登录
            # 8.从cookie中获取数据
            cookie_cart = request.COOKIES.get('carts')

            # 9.判断是否存在, 如果存在, 解密 ===> cart_dict
            if cookie_cart:
                cart_dict = pickle.loads(base64.b64decode(cookie_cart))
            else:
                # 10.如果不存在, 创建新的cart_dict
                cart_dict = {}

        # 11.整体操作:
        # 12.从cart_dict中获取所有的sku_ids
        sku_ids = cart_dict.keys()

        # 13.把sku_ids====> skus
        try:
            skus = SKU.objects.filter(id__in=sku_ids)
        except Exception as e:
            return JsonResponse({'code':400,
                                 'errmsg':'获取商品出错'})

        list = []

        # 14.遍历skus===>sku===>{}===>[]
        for sku in skus:
            list.append({
                'id':sku.id,
                'name':sku.name,
                'count':cart_dict[sku.id]['count'],
                'default_image_url':sku.default_image_url
            })

        # 15.返回
        return JsonResponse({'code':0,
                             'errmsg':'ok',
                             'cart_skus':list})
















































