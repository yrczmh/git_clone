from django.views import View
from django_redis import get_redis_connection
# from meiduo_mall.meiduo_mall.libs.captcha.captcha import captcha
from django.http import HttpResponse, JsonResponse

from celery_tasks.sms.tasks import send_sms_code
from meiduo_mall.libs.captcha.captcha import captcha
import logging

from meiduo_mall.libs.yuntongxun.ccp_sms import CCP

logger = logging.getLogger('django')
import random

class ImageCodeView(View):


    def get(self, request, uuid):
        '''生成图形验证码并返回'''

        # 1.生成图片&值
        text, image = captcha.generate_captcha()

        # 2.链接redis,获取链接对象
        redis_conn = get_redis_connection('verify_code')

        # 3.把值保存到redis
        redis_conn.setex('img_%s' % uuid, 300, text)

        # 4.返回图片
        return HttpResponse(image, content_type='image/jpg')


class SMSCodeView(View):

    def get(self, request, mobile):
        '''发送短信验证码的接口实现'''
        redis_conn = get_redis_connection('verify_code')

        # 0. 从redis中获取一个keyvalue键值对
        flag = redis_conn.get('flag_mobile_%s' % mobile)

        # 查看该value是否存在, 如果存在, 直接返回, 如果不存在, 执行下面的代码:
        if flag:
            return JsonResponse({'code':400,
                                 'errmsg':'请勿频繁发送短信验证码'})

        # 1.接收查询字符串参数(2个)
        image_code_client = request.GET.get('image_code')
        uuid = request.GET.get('image_code_id')

        # 2.总体检验,查看是否齐全
        if not all([image_code_client, uuid]):
            return JsonResponse({'code':400,
                                 'errmsg':'缺少必传参数'})

        # 3.链接redis, 获取redis的链接对象

        # 4.从redis中获取图片验证码
        image_code_server = redis_conn.get('img_%s' % uuid)

        # 5.判断该图片验证码是否过期
        if image_code_server is None:
            return JsonResponse({'code': 400,
                                 'errmsg': '服务端的图形验证码过期'})

        # 6.删除图片验证码
        try:
            redis_conn.delete('img_%s' % uuid)
        except Exception as e:
            logger.error(e)

        # 7.对比前后端的图形验证码,如果不相等, 返回报错
        if image_code_client.lower() != image_code_server.decode().lower():
            return JsonResponse({'code': 400,
                                 'errmsg': '输入的验证吗有误'})

        # 8.生成短信验证码
        sms_code = '%06d' % random.randint(0, 999999)
        print(sms_code)

        # 创建管道
        pl = redis_conn.pipeline()

        # 9.在redis中保存短信验证码
        pl.setex('sms_%s' % mobile, 300, sms_code)

        # 补充: 往redis中存储一个keyvalue:
        pl.setex('flag_mobile_%s' % mobile, 60, 1)

        # 执行管道
        pl.execute()

        # 10.调用容联云发送短信验证码
        # CCP().send_template_sms(mobile, [sms_code, 5], 1)
        # 抛出celery任务
        send_sms_code.delay(mobile, sms_code)

        # 11.返回结果(json)
        return JsonResponse({'code':0,
                             'errmsg':'ok'})

