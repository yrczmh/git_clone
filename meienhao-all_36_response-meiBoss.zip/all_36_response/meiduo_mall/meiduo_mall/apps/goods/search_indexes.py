# 定义索引表的模型类:
from haystack import indexes

from goods.models import SKU


class SKUIndex(indexes.Indexable, indexes.SearchIndex):

    text = indexes.CharField(document=True, use_template=True)

    def get_model(self):
        return SKU


    def index_queryset(self, using=None):
        return self.get_model().objects.filter(is_launched=True)