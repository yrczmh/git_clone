from django.core.paginator import Paginator
from django.views import View
from django.http import JsonResponse

# Create your views here.
from goods.models import GoodsCategory, SKU
from goods.utils import get_breadcrumb


class ListView(View):

    def get(self, request, category_id):
        '''返回列表页的数据'''
        
        # 1.接收参数
        page = request.GET.get('page')
        page_size = request.GET.get('page_size')
        ordering = request.GET.get('ordering')

        # 2.校验参数
        if not all([page, page_size, ordering]):
            return JsonResponse({'code':400,
                                 'errmsg':"缺少参数"})

        # 3.根据category_id, 获取对应的类别
        try:
            category = GoodsCategory.objects.get(id=category_id)

        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': "获取类别失败"})

        dict = get_breadcrumb(category)


        # 4.从SKU表中获取该类别的,上架的商品===> 按前端的要求排序
        try:
            skus = SKU.objects.filter(category=category,
                               is_launched=True).order_by(ordering)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': "获取类别失败"})

        # 5.利用导入的分页类创建对象
        paginator = Paginator(skus, page_size)

        # 6.调用分页对象的page(页码) ===> 对应页码的数据skus(5个)
        try:
            page_skus = paginator.page(page)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': "获取该页数据失败"})

        # 7.调用分页对象获取总的页码
        total_pages = paginator.num_pages

        list = []

        # 8.遍历对应页码的数据, 获取每一个sku ===> {} ===> []
        for sku in page_skus:
            list.append({
                'id':sku.id,
                'default_image_url':sku.default_image_url,
                'name':sku.name,
                'price':sku.price
            })

        # 9.整理数据, 返回json
        return JsonResponse({'code':0,
                             'errmsg':'ok',
                             'count':total_pages,
                             'list':list,
                             'breadcrumb':dict})


class HotListView(View):

    def get(self, request, category_id):

        try:
            skus = SKU.objects.filter(category_id=category_id,
                                      is_launched=True).order_by('-sales')[:2]
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': "获取类别失败"})
        list = []

        for sku in skus:
            list.append({
                'id': sku.id,
                'default_image_url': sku.default_image_url,
                'name': sku.name,
                'price': sku.price
            })

        return JsonResponse({'code': 0,
                             'errmsg': 'ok',
                             'hot_skus': list})




# 导入:
from haystack.views import SearchView



class MySearchView(SearchView):
    '''重写SearchView类'''
    def create_response(self):
        page = self.request.GET.get('page')
        # 获取搜索结果
        context = self.get_context()
        data_list = []
        for sku in context['page'].object_list:
            data_list.append({
                'id':sku.object.id,
                'name':sku.object.name,
                'price':sku.object.price,
                'default_image_url':sku.object.default_image_url,
                'searchkey':context.get('query'),
                'page_size':context['page'].paginator.num_pages,
                'count':context['page'].paginator.count
            })
        # 拼接参数, 返回
        return JsonResponse(data_list, safe=False)

















