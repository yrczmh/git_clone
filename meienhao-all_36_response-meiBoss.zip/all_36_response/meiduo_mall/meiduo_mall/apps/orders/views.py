from decimal import Decimal
import json

from django.db import transaction
from django.utils import timezone
from django.views import View
from django.http import JsonResponse

from goods.models import SKU
from meiduo_mall.utils.Views import LoginRequiredMixin
from orders.models import OrderInfo, OrderGoods
from users.models import Address
from django_redis import get_redis_connection

class OrderSettlementView(LoginRequiredMixin, View):
    
    
    def get(self, request):
        '''返回订单页面数据'''
        
        # 1.从mysql中Address获取该用户的所有没有删除的地址==>addresses
        try:
            addresses = Address.objects.filter(user=request.user,
                                   is_deleted=False)
        except Exception as e:
            return JsonResponse({'code':400,
                                 'errmsg':'地址没有获取到'})

        list = []

        # 2.遍历addresses所有的地址===>address===>{}====>[]
        for address in addresses:
            list.append({
                'id':address.id,
                'province':address.province.name,
                'city':address.city.name,
                'district':address.district.name,
                'place':address.place,
                'mobile':address.mobile,
                'receiver':address.receiver
            })

        # 3.链接redis, 获取链接对象
        redis_conn = get_redis_connection('carts')

        # 4.从redis的hash中获取count
        item_dict = redis_conn.hgetall('carts_%s' % request.user.id)

        # 5.从set中获取sku_ids(选中的商品的ids)
        selected_item = redis_conn.smembers('selected_%s' % request.user.id)

        dict = {}

        # 6.把hash中的count和set中的sku_id整理到dict={sku_id:count}
        for sku_id in selected_item:
            dict[int(sku_id)] = int(item_dict[sku_id])

        try:
            # 7.把dict中的sku_id都变成sku
            skus = SKU.objects.filter(id__in=dict.keys())
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': 'sku没有获取到'})

        sku_list = []

        # 8.获取所有的商品, 遍历skus====>sku====>{}====>[]
        for sku in skus:
            sku_list.append({
                'id':sku.id,
                'name':sku.name,
                'default_image_url':sku.default_image_url,
                'count':dict[sku.id],
                'price':sku.price
            })

        # 9.定义一个运费的变量
        yunfei = Decimal('10.00')

        # 10.整理数据
        dict = {
            'addresses':list,
            'skus':sku_list,
            'freight':yunfei
        }

        # 11.返回
        return JsonResponse({'code': 0,
                             'errmsg': 'ok',
                             'context':dict})

class SaveOrdersView(View):

    def post(self, request):
        '''保存订单信息'''

        # 1.接收参数json(address_id+pay_method)
        dict = json.loads(request.body)
        address_id = dict.get('address_id')
        pay_method = dict.get('pay_method')

        # 2.总体检验
        if not all([address_id, pay_method]):
            return JsonResponse({'code':400,
                                 'errmsg':'缺少参数'})

        # 3.单个检验
        try:
            address = Address.objects.get(id=address_id)
        except Exception as e:
            return JsonResponse({'code':400,
                                 'errmsg':'address_id有误'})

        if pay_method not in [1, 2]:
            return JsonResponse({'code': 400,
                                 'errmsg': 'pay_method有误'})

        user = request.user

        # 创建一个order_id: 年月日时分秒 + 9位的用户id
        order_id = timezone.localtime().strftime('%Y%m%d%H%M%S') + ('%09d' % user.id)

        with transaction.atomic():

            save_id = transaction.savepoint()

            # 4.OrderInfo中存储订单的基本信息
            order = OrderInfo.objects.create(
                order_id = order_id,
                user = user,
                address = address,
                total_count = 0,
                total_amount = Decimal('0'),
                freight = Decimal('10.00'),
                pay_method = pay_method,
                status = 1 if pay_method == 2 else 2
            )
            # 5.链接redis, 获取链接对象
            redis_conn = get_redis_connection('carts')

            # 6.从redis的hash(user_id:{sku_id:count})中取出count
            item_dict = redis_conn.hgetall('carts_%s' % user.id)

            # 7.从redis的set中获取sku_id
            selected_item = redis_conn.smembers('selected_%s' % user.id)

            dict = {}
            # 8.整理:  dict = {sku_id:count}
            for sku_id in selected_item:
                dict[int(sku_id)] = int(item_dict[sku_id])

            # 9.从dict中获取所有的sku_ids
            sku_ids = dict.keys()

            # 10.遍历sku_ids ===> sku_id
            for sku_id in sku_ids:

                while True:

                    # 11.把sku_id变为sku
                    sku = SKU.objects.get(id=sku_id)

                    count = dict.get(sku_id)

                    # 定义一个变量, 保存原始的库存量和销售数量
                    origin_stock = sku.stock
                    origin_sales = sku.sales

                    # origin_goods_sales = sku.goods.sales

                    # 12.判断该sku的stock与销售数量间的关系, 如果销售数量 > stock, 返回
                    if sku.stock < count:
                        transaction.savepoint_rollback(save_id)
                        return JsonResponse({'code':400,
                                             'errmsg':'库存不足'})

                    # 13.更改sku的销量&库存===> 保存
                    # sku.stock -= count
                    # sku.sales += count
                    # sku.save()

                    new_stock = sku.stock - count
                    new_sales = sku.sales + count

                    result = SKU.objects.filter(
                        id=sku_id,
                        stock=origin_stock
                    ).update(stock=new_stock, sales=new_sales)

                    # 判断是否进行了更改:
                    if result == 0:
                        continue

                    # 14.更改spu的销量 ====> 保存
                    sku.goods.sales += count
                    sku.goods.save()

                    # 15.把sku相关数据保存到订单商品表中OrderGoods
                    OrderGoods.objects.create(
                        order = order,
                        sku = sku,
                        count = count,
                        price = sku.price
                    )

                    # 更新order的两个字段:
                    order.total_count += count
                    order.total_amount += (count * sku.price)

                    break

            order.total_amount += order.freight
            order.save()

        redis_conn.hdel('carts_%s' % request.user.id, *selected_item)
        redis_conn.srem('selected_%s' % request.user.id, *selected_item)

        return JsonResponse({'code':0,
                             'errmsg':'ok',
                             'order_id':order_id})


































