from django.views import View
from .models import  Area
from django.http import JsonResponse
from django.core.cache import cache

class ProvinceView(View):

    def get(self, request):
        '''返回省份数据'''
        list = cache.get('province_list')

        if not list:

            try:
                # 1.从mysql中获取省份数据
                province_models_list = Area.objects.filter(parent__isnull=True)

                list = []

                # 2.遍历所有的数据, 获取每一个省份 ===> {} ===> []
                for province in province_models_list:
                    list.append({
                        'id':province.id,
                        'name':province.name
                    })

                cache.set('province_list', list, 3600)
            except Exception as e:
                return JsonResponse({'code':400,
                                     'errmsg':'获取失败'})
        # 3.拼接参数, 返回
        return JsonResponse({'code': 0,
                             'errmsg': 'ok',
                             'province_list':list})



class SubAreasView(View):

    def get(self, request, pk):
        '''返回市数据'''

        dict = cache.get('sub_data_' + pk)

        if not dict:

            try:
                # 1.从mysql中获取市的数据
                # parent: 数字/对象
                sub_list = Area.objects.filter(parent_id=pk)

                # 2.从mysql中获取省的数据
                province = Area.objects.get(id=pk)

                list = []
                # 3.遍历所有的市的数据, 获取每一个市 ====> {}  ====> []
                for sub in sub_list:
                    list.append({
                        'id':sub.id,
                        'name':sub.name
                    })

                # 4.把[]整理到{}中
                dict = {
                    # 'id':pk,
                    'id':province.id,
                    'name':province.name,
                    'subs':list
                }

                cache.set('sub_data_' + pk, dict, 3600)

            except Exception as e:
                return JsonResponse({'code': 400,
                                     'errmsg': '获取失败'})

        # 5.返回json({}===>{})
        return JsonResponse({'code': 0,
                             'errmsg': 'ok',
                             'sub_data':dict})






























