from alipay import AliPay
from django.views import View
from django.http import JsonResponse
from orders.models import OrderInfo
from django.conf import settings
import os

from payment.models import Payment


class PaymentsView(View):

    def get(self, request, order_id):
        '''返回支付宝支付地址的接口'''
        
        # 1.在OrderInfo表中验证order_id是否为真
        try:
            order = OrderInfo.objects.get(order_id=order_id,
                                  user=request.user,
                                  status=1)
        except Exception as e:
            return JsonResponse({'code':400,
                                 'errmsg':'order_id有误'})

        # 2.调用python-alipay-sdk工具类, 创建一个对象
        alipay = AliPay(
            appid=settings.ALIPAY_APPID,
            app_notify_url=None,  # 默认回调url
            app_private_key_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys/app_private_key.pem"),
            alipay_public_key_path=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                "keys/alipay_public_key.pem"),
            sign_type="RSA2",
            debug=settings.ALIPAY_DEBUG
        )

        # 3.调用对象的方法 ====>  拼接好的字符串(参数)
        order_string = alipay.api_alipay_trade_page_pay(
            out_trade_no=order_id,
            total_amount=str(order.total_amount),
            subject="美多商城%s" % order_id,
            return_url=settings.ALIPAY_RETURN_URL,
        )

        # 4.把支付宝的网关(url) + 字符串  ====> 完整的地址
        url = settings.ALIPAY_URL + '?' + order_string

        # 5.返回json
        return JsonResponse({'code':0,
                             'errmsg':'ok',
                             'alipay_url':url})


class PaymentSuccessView(View):

    def put(self, request):
        '''保存支付结果'''

        # 1.接收参数(查询字符串)
        query_dict = request.GET

        # 2.把查询字符串中的dict获取到
        dict = query_dict.dict()

        # 3.从dict中剔除sign对应的部分, 定义一个变量获取剔除的结果(signature)
        signature = dict.pop('sign')

        # 4.获取python-alipy-adk工具类的对象
        alipay = AliPay(
            appid=settings.ALIPAY_APPID,
            app_notify_url=None,  # 默认回调url
            app_private_key_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys/app_private_key.pem"),
            alipay_public_key_path=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                "keys/alipay_public_key.pem"),
            sign_type="RSA2",
            debug=settings.ALIPAY_DEBUG
        )

        # 5.调用对象的verify(剔除后的dict, signature) ===> bool
        success = alipay.verify(dict, signature)

        # 6.根据获取的bool值,判断是否支付成功,如果true, 成功.
        if success:
            # 7.dict ====> order_id&trade_id
            order_id = dict.get('out_trade_no')
            trade_id = dict.get('trade_no')

            # 8.把order_id&trade_id保存到payment模型类中.
            Payment.objects.create(
                order_id = order_id,
                trade_id = trade_id
            )

            # 补充: 更改订单的状态:
            OrderInfo.objects.filter(order_id=order_id).update(status=2)

            # 9.拼接参数, 返回结果
            return JsonResponse({'code':0,
                                 'errmsg':"ok",
                                 "trade_id":trade_id})
        else:
            return JsonResponse({'code': 400,
                                 'errmsg': "非法请求"})


































