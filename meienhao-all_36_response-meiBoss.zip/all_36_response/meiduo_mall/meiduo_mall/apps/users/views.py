from django.contrib.auth import login, authenticate, logout
from django.views import View

from carts.utils import merge_carts_cookie_to_redis
from celery_tasks.email.tasks import send_verify_email
from goods.models import SKU
from meiduo_mall.utils.Views import LoginRequiredMixin
from .models import User, Address
from django.http import JsonResponse, HttpResponse
import json, re
from django_redis import get_redis_connection

class UsernameCountView(View):

    def get(self, request, username):
        '''接收用户名,判断是否重复注册'''

        # 进入数据库User中查询username相关的用户名的个数,获取个数
        try:
            count = User.objects.filter(username=username).count()
        except Exception as e:

            return JsonResponse({
                'code':400,
                'errmsg':'查询数据库失败'
            })

        # 拼接json字符串, 返回前端
        return JsonResponse({
                'code':0,
                'errmsg':'ok',
                'count':count
            })


class MobileCountView(View):

    def get(self, request, mobile):
        '''接收手机号,判断是否重复注册'''

        # 进入数据库User中查询手机号相关的手机号的个数,获取个数
        try:
            count = User.objects.filter(mobile=mobile).count()
        except Exception as e:

            return JsonResponse({
                'code':400,
                'errmsg':'查询数据库失败'
            })

        # 拼接json字符串, 返回前端
        return JsonResponse({
                'code':0,
                'errmsg':'ok',
                'count':count
            })



class RegisterView(View):

    def post(self, request):
        '''注册的接口'''

        # 1.接收参数
        dict = json.loads(request.body)
        username = dict.get('username')
        password = dict.get('password')
        password2 = dict.get('password2')
        mobile = dict.get('mobile')
        allow = dict.get('allow')
        sms_code_client = dict.get('sms_code')

        # 2.校验(整体)
        if not all([username, password, password2, mobile, allow, sms_code_client]):
            return JsonResponse({'code':400,
                                 'errmsg':"缺少必传参数"})

        # 3.username检验
        if not re.match(r'^[a-zA-Z0-9_-]{5,20}$', username):
            return JsonResponse({'code': 400,
                                 'errmsg': "username有误"})

        # 4.password检验
        if not re.match(r'^[a-zA-Z0-9]{8,20}$', password):
            return JsonResponse({'code': 400,
                                 'errmsg': "password有误"})

        if password2 != password:
            return JsonResponse({'code': 400,
                                 'errmsg': "两次输入密码不一致"})

        # 6.mobile检验
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return JsonResponse({'code': 400,
                                 'errmsg': "mobile有误"})
        # 7.allow检验
        if allow != True:
            return JsonResponse({'code': 400,
                                 'errmsg': "allow有误"})

        # 8.sms_code检验 (链接redis数据库)
        redis_conn = get_redis_connection('verify_code')

        # 9.从redis中取值
        sms_code_server = redis_conn.get('sms_%s' % mobile)

        # 10.判断该值是否存在
        if not sms_code_server:
            return JsonResponse({'code': 400,
                                 'errmsg': "sms_code_server过期"})

        # 11.把redis中取得值和前端发的值对比
        if sms_code_client != sms_code_server.decode():
            return JsonResponse({'code': 400,
                                 'errmsg': "输入的短信验证码有误"})

        try:
            # 12.保存到数据库 (username password mobile)
            user = User.objects.create_user(username=username,
                                     password=password,
                                     mobile=mobile)
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': "往数据库保存数据失败"})


        # 增加状态保持:
        login(request, user)


        # 13.拼接json返回
        response = JsonResponse({'code': 0,
                                 'errmsg': "ok"})

        # 往cookie中写入数据:
        response.set_cookie('username', user.username, 300)

        # 增加合并购物车功能:
        response = merge_carts_cookie_to_redis(request, response)

        # 7.返回json
        return response


class LoginView(View):

    def post(self, request):
        '''登录的接口'''

        # 1.接收json参数
        dict = json.loads(request.body)
        username = dict.get('username')
        password = dict.get('password')
        remembered = dict.get('remembered')

        # 2.检验
        if not all([username, password]):
            return JsonResponse({'code': 400,
                                 'errmsg': "缺少必传参数"})

        # 3.认证是否登录, 获取登录用户(有可能为空)
        user = authenticate(username=username,
                            password=password)

        # 4.判断用户是否为空
        if user is None:
            return JsonResponse({'code': 400,
                                 'errmsg': "用户名或者密码错误"})

        # 5.判断是否记住登录, 如果没有记住==> 有效期设置0,记住===> 默认
        if remembered != True:
            # 如果没有记住==> 有效期设置0
            request.session.set_expiry(0)
        else:
            request.session.set_expiry(None)

        # 6.状态保持
        login(request, user)

        response = JsonResponse({'code': 0,
                             'errmsg': "ok"})

        # 往cookie中写入数据:
        response.set_cookie('username', user.username, 300)


        # 增加合并购物车功能:
        response = merge_carts_cookie_to_redis(request, response)

        # 7.返回json
        return response




class LogoutView(View):

    def delete(self, request):
        '''退出登录'''

        # 1.清除所有的session&sessionid ===> logout()
        logout(request)

        response = JsonResponse({'code':0,
                                 'errmsg':"ok"})

        # 2.清除cookie中的username
        response.delete_cookie('username')

        # 3.返回json
        return response




class UserInfoView(LoginRequiredMixin, View):

    def get(self, request):
        '''返回用户中心页面信息'''

        # 1.拼接用户的信息
        dict = {
            'username': request.user.username,
            'mobile': request.user.mobile,
            'email': request.user.email,
            'email_active': request.user.email_active
        }

        # 2.整理成json, 返回
        return JsonResponse({'code': 0,
                             'errmsg': 'ok',
                             'info_data': dict})


class EmailView(LoginRequiredMixin, View):

    def put(self, request):
        '''增加email到数据库'''

        # 1.接收json参数
        dict = json.loads(request.body)
        email = dict.get('email')

        # 2.检验参数
        if not email:
            return JsonResponse({'code': 400,
                                 'errmsg': '缺少email'})
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
            return JsonResponse({'code': 400,
                                 'errmsg': '格式不正确'})
        try:
            # 3.修改数据库
            request.user.email = email

            # 4.保存
            request.user.save()
        except  Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': '保存失败'})

        verify_url = request.user.generate_verify_url()

        # 给当前的email发送邮件:
        send_verify_email.delay(email, verify_url)

        # 5.返回json
        return JsonResponse({'code': 0,
                             'errmsg': 'ok'})


class VerifyEmailView(View):
    
    def put(self, request):
        '''验证链接'''
        
        # 1.接收参数token
        token = request.GET.get('token')

        # 2.检验token是否存在
        if not token:
            return JsonResponse({'code': 400,
                                 'errmsg': '缺少token'})

        # 3.把token解密 ====> user
        user = User.decode_access_token(token)

        if user is None:
            return JsonResponse({'code': 400,
                                 'errmsg': 'token有误'})

        # 4.把user的email_active改为true
        try:
            user.email_active = True

            # 5.保存
            user.save()
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': '保存失败'})

        # 6.返回结果
        return JsonResponse({'code': 0,
                            'errmsg': 'ok'})



class CreateAddressView(View):

    def post(self, request):
        '''接收地址,并保存'''

        # 0 判断当前用户下面的地址是否超过20个
        try:
            count = Address.objects.filter(user=request.user,
                                           is_deleted=False).count()
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': '获取失败'})

        if count >= 20:
            return JsonResponse({'code': 400,
                                 'errmsg': '超过个数'})

        # 1.接收json参数
        json_dict = json.loads(request.body.decode())
        receiver = json_dict.get('receiver')
        province_id = json_dict.get('province_id')
        city_id = json_dict.get('city_id')
        district_id = json_dict.get('district_id')
        place = json_dict.get('place')
        mobile = json_dict.get('mobile')
        tel = json_dict.get('tel')
        email = json_dict.get('email')

        # 2.总体校验
        if not all([receiver, province_id, city_id, district_id, place, mobile]):
            return JsonResponse({'code':400,
                                 'errmsg':'缺少参数'})

        # 3.对于mobile检验正则
        if not re.match(r'1[3-9]\d{9}$', mobile):
            return JsonResponse({'code': 400,
                                 'errmsg': 'mobile格式不对'})
        # 4.对tel检验
        if tel:
            if not re.match(r'(0[0-9]{2,3}-)?([2-9][0-9]{6,7})+(-[0-9]{1,4})?$', tel):
                return JsonResponse({'code': 400,
                                     'errmsg': 'tel格式不对'})
        # 5.对email检验
        if email:
            if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
                return JsonResponse({'code': 400,
                                     'errmsg': 'email格式不对'})
        # 6.往Address中保存地址
        try:
           address = Address.objects.create(
                user=request.user,
                province_id = province_id,
                district_id = district_id,
                city_id = city_id,
                title = receiver,
                receiver = receiver,
                place = place,
                mobile = mobile,
                tel = tel,
                email = email,
            )

            # 7.判断是否有默认地址, 如果没有, 把当前的地址设置为默认地址
           if not request.user.default_address:
                request.user.default_address = address

                request.user.save()
        except Exception as e:
            return JsonResponse({'code': 400,
                                 'errmsg': '保存失败'})


        # 8.拼接参数
        address_dict = {
            "id": address.id,
            "title": address.title,
            "receiver": address.receiver,
            "province": address.province.name,
            "city": address.city.name,
            "district": address.district.name,
            "place": address.place,
            "mobile": address.mobile,
            "tel": address.tel,
            "email": address.email
        }

        # 9.返回
        return JsonResponse({'code':0,
                             'errmsg':'ok',
                             'address':address_dict})




class SaveHistoryView(View):

    def post(self, request):
        '''保存浏览记录'''

        # 1.接收json参数获取sku_id
        dict = json.loads(request.body)
        sku_id = dict.get('sku_id')

        # 2.检验sku_id
        try:
            SKU.objects.get(id=sku_id)
        except Exception   as e:
            return JsonResponse({'code': 400,
                                 'errmsg': 'sku_id有误'})

        # 3.链接redis, 获取链接对象
        redis_conn = get_redis_connection('history')

        user_id = request.user.id

        pl = redis_conn.pipeline()

        # 4.去重
        pl.lrem('history_%s' % user_id, 0, sku_id)

        # 5.增加
        pl.lpush('history_%s' % user_id, sku_id)

        # 6.截取
        pl.ltrim('history_%s' % user_id, 0, 4)

        # 执行管道:
        pl.execute()

        # 7.返回
        return JsonResponse({'code': 0,
                             'errmsg': 'ok'})


    def get(self, request):
        '''返回浏览记录'''

        # 1.链接redis, 获取链接对象
        redis_conn = get_redis_connection('history')

        # 2.从list中获取全部sku_ids
        sku_ids = redis_conn.lrange('history_%s' % request.user.id, 0, -1)

        list = []

        # 4.遍历skus 获取每一个sku  ===> {} ===> []
        for sku_id in sku_ids:
            sku = SKU.objects.get(id=sku_id)
            list.append({
                'id':sku.id,
                'default_image_url':sku.default_image_url,
                'name':sku.name,
                'price':sku.price
            })

        # 5.返回json
        return JsonResponse({'code': 0,
                             'errmsg': 'ok',
                             'skus':list})




























