#!/Users/meihao/.virtualenvs/meiduo_mall/bin/python

import sys

sys.path.insert(0, '../../')

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'meiduo_mall.settings.dev')

# 初始化django
import django
django.setup()

from celery_tasks.html.tasks import generate_detail_func

for i in range(1,17):
    generate_detail_func.delay(i)