#!/Users/meihao/.virtualenvs/meiduo_mall/bin/python

from fdfs_client.client import Fdfs_client

client = Fdfs_client('/Users/meihao/Desktop/all_36_response/meiduo_mall/meiduo_mall/utils/fastdfs/client.conf')

ret = client.upload_by_filename('/Users/meihao/Desktop/demo.jpg')

print(ret)